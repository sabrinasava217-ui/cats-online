# Opsional: membuat ulang ikon. Hasilnya sudah ada di resources/android/
from PIL import Image, ImageDraw
import os
BROWN=(109,64,40); PINK=(244,143,177); PEACH=(255,204,153)
def cat(d,cx,cy,r):
    w=max(2,int(r*0.07))
    for sx in (-1,1):
        p=[(cx+sx*r*0.95,cy-r*0.15),(cx+sx*r*0.8,cy-r*1.15),(cx+sx*r*0.15,cy-r*0.7)]
        d.polygon(p,fill=PINK); d.line(p+[p[0]],fill=BROWN,width=w)
    d.ellipse([cx-r,cy-r*0.75,cx+r,cy+r*0.85],fill=PINK,outline=BROWN,width=w)
    for sx in (-1,1):
        ex,ey=cx+sx*r*0.4,cy-r*0.05
        d.ellipse([ex-r*.11,ey-r*.14,ex+r*.11,ey+r*.14],fill=(62,39,35))
        d.ellipse([ex-r*.04,ey-r*.09,ex+r*.02,ey-r*.03],fill=(255,255,255))
        d.line([(cx+sx*r*0.65,cy+r*0.3),(cx+sx*r*1.05,cy+r*0.22)],fill=BROWN,width=max(2,w//2))
        d.line([(cx+sx*r*0.65,cy+r*0.4),(cx+sx*r*1.05,cy+r*0.45)],fill=BROWN,width=max(2,w//2))
    d.polygon([(cx-r*.1,cy+r*.2),(cx+r*.1,cy+r*.2),(cx,cy+r*.33)],fill=(216,74,115))
def make(size,kind):
    S=size*4; im=Image.new('RGBA',(S,S),(0,0,0,0)); d=ImageDraw.Draw(im)
    if kind=='legacy': d.rounded_rectangle([0,0,S-1,S-1],radius=int(S*.2),fill=PEACH); cat(d,S/2,S*.53,S*.32)
    elif kind=='round': d.ellipse([0,0,S-1,S-1],fill=PEACH); cat(d,S/2,S*.53,S*.30)
    else: cat(d,S/2,S*.53,S*.20)
    return im.resize((size,size),Image.LANCZOS)
dens={'mdpi':(48,108),'hdpi':(72,162),'xhdpi':(96,216),'xxhdpi':(144,324),'xxxhdpi':(192,432)}
for k,(l,f) in dens.items():
    o=f'resources/android/mipmap-{k}'; os.makedirs(o,exist_ok=True)
    make(l,'legacy').save(f'{o}/ic_launcher.png'); make(l,'round').save(f'{o}/ic_launcher_round.png')
    make(f,'fg').save(f'{o}/ic_launcher_foreground.png')
